HS3 Life360

- Features
    - Reads from a configuration file
        - HS3 URL
        - Life 360 Username/Password
        - Manually added family circle members

    - Auto configure based on members in family circle
        - Auto adds missing family member entries (minus HS3 Device Reference Number)

- Setup
    - Add the HS3 Device Reference number to the configuration file
        - Edit HS3-Life360.exe.config
        - Add HS3 Device Reference number as value for each circle member 
            - Replace "000" with the Ref number
    - Execute
        - Manually run the .exe to test out.
        - Add job to Task Scheduler to run periodically
    